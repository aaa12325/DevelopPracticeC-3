package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Address;
import bean.Order;
import bean.OrderedUniform;
import bean.User;
import dao.OrderDAO;
import dao.UniformDAO;
import dao.UserDAO;

public class UpdateStockServlet extends HttpServlet {
	//getメソッド対応
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		//UTF-8で受け取る
		request.setCharacterEncoding("UTF-8");

		//エラー用
		String error = null;
		String cmd = "";

		try {

			int stock = 0;

			try {
				stock = Integer.parseInt(request.getParameter("stock"));
			}catch(NumberFormatException e) {
				error = "在庫変更には数値を入力して下さい。";
				cmd = "list";
				return;
			}
			String productId = request.getParameter("productId");

			new UniformDAO().updateStock(stock,productId);

		}catch(IllegalStateException e) {
			error = "DB接続エラー";
			cmd = "logout";
		}catch(Exception e) {
			error = "想定外のエラー";
			cmd = "logout";
		}
		finally {
			if(error != null) { //エラー時
				request.setAttribute("error",error); //エラーメッセージ登録
				request.setAttribute("cmd",cmd); //リンクの種類登録
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);//エラーページにフォワード
			}else { //エラーなし
				request.getRequestDispatcher("/uniformList").forward(request, response); //詳細表示
			}
		}
	}
}
