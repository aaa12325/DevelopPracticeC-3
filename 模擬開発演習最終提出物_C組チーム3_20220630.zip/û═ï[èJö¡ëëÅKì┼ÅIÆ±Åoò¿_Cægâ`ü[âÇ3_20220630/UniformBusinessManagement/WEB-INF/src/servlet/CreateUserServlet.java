package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class CreateUserServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";
		boolean already= false;

		try {

			request.setCharacterEncoding("UTF-8");

			String name = request.getParameter("name");
			String nameP = request.getParameter("nameP");
			String mail = request.getParameter("mail");
			String pass = request.getParameter("pass");
			String passC = request.getParameter("passC");
			String adress = request.getParameter("adress");
			String prefecture = request.getParameter("prefecture");
			String municipalities = request.getParameter("municipalities");
			String houseNumber = request.getParameter("houseNumber");
			String other = request.getParameter("other");
			String tell = request.getParameter("tell");

			// 空白チェック
			if (name.equals("")) {
				error = "名前が未入力の為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			if (nameP.equals("")) {
				error = "名前(ふりがな)が未入力の為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			if (mail.equals("")) {
				error = "メールが未入力の為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			if (pass.equals("")) {
				error = "パスワードが未入力の為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			if (passC.equals("")) {
				error = "パスワード確認用が未入力の為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			if (adress.equals("")) {
				error = "郵便番号が未入力の為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			if (prefecture.equals("")) {
				error = "都道府県が未入力の為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			if (municipalities.equals("")) {
				error = "市区町村が未入力の為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			if (houseNumber.equals("")) {
				error = "町名、番地が未入力の為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			if (tell.equals("")) {
				error = "電話番号が未入力の為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			// パスワード一致チェック
			if (!pass.equals(passC)) {
				error = "入力されたパスワードが一致しない為、会員登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			UserDAO objDao = new UserDAO();

			User user = objDao.selectById(mail);

			if(user != null) {
				if(user.getAuthority().equals("2")) {
					already = true;
				}
				else {
					error = "入力したメールアドレスは既に会員登録に使用されています！";
					cmd = "menu";
					return;
				}
			}

			// ユーザーセット
			user = new User();
			user.setName(name);
			user.setNamePhonetic(nameP);
			user.setMail(mail);
			user.setPassword(pass);
			user.setTelephoneNumber(tell);
			user.setAuthority("0");

			user.setZipCode(adress);
			user.setPrefecture(prefecture);
			user.setMunicipalities(municipalities);
			user.setHouseNumber(houseNumber);
			user.setOther(other);

			if(already) {
				objDao.update(user);
			}else {
				// セットしたのをインサート
				objDao.insert(user);
			}

			request.setAttribute("success","登録が完了しました！" );

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、ユーザー登録処理は行えませんでした。";
			cmd = "menu";
		} finally {
			// エラー有無フォワード
			if (error.equals("")) {
				// エラー無しListServletフォワード
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			} else {
				// エラー有りerror.jspフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}