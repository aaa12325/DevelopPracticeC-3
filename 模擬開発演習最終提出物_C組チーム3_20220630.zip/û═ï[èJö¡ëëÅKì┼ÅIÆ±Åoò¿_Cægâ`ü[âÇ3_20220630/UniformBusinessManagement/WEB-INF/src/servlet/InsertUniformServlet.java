/* プログラム名：UniformBusinessManagement
 * プログラムの説明：新しく商品（ユニフォーム）を登録するサーブレット
 * 作成日：6月23日
 * 作成者：長田麻由
 *
 */
package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.oreilly.servlet.MultipartRequest;

import bean.Uniform;
import dao.UniformDAO;

public class InsertUniformServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {


		// 入力情報を受け取るためのエンコードを行う
		request.setCharacterEncoding("UTF-8");



		String error = "";
		String cmd = "list";

		try {




			//アップロードファイルを格納するPATHを取得
			String FilePath = getServletContext().getRealPath("image");

			//ファイル名
			String imageName = "no_image.jpg";

			// ファイルの最大バイト数
			int maxBytes = 1024*1024;
			MultipartRequest multireq= new MultipartRequest(request,FilePath,maxBytes,"UTF-8");

			String productId = multireq.getParameter("product_id");  //商品ID

			try {
				Integer.parseInt(productId);
			}catch(NumberFormatException e) {
				error="商品番号には数値を登録してください。";
				cmd = "menu";
				return;
			}

			String productName = multireq.getParameter("product_name"); //商品名
			String price = multireq.getParameter("price"); //価格
			String stock = multireq.getParameter("stock"); //在庫数
			String material = multireq.getParameter("material"); //素材
			String detail = multireq.getParameter("detail"); //詳細説明

			if(multireq.getFile("image") != null){
				imageName = multireq.getFile("image").getName();
			}


			// UniformDAOオブジェクト宣言
			UniformDAO uniformDao = new UniformDAO();

			// ユニフォームの商品登録情報を格納するオブジェクト
			Uniform objUni =  uniformDao.selectByProductId(productId);

			if (objUni != null) {
				error = "入力商品番号は既に登録済みの為、商品登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}else if (productName.equals("")) {
				error = "商品名が未入力の為、商品登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}else if (price.equals("")) {
				error = "価格が未入力の為、商品登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}else if (stock.equals("")){
				error = "在庫数が未入力の為、商品登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}else if (material.equals("")){
				error = "素材が未入力の為、商品登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}
			try {
				Integer.parseInt(price);
			} catch (NumberFormatException e) {
				// 文字が入力された場合のエラー設定
				error = "価格の値が不正の為、商品登録は行えませんでした。";
				cmd = "menu";
				return;
			}
			try {
				Integer.parseInt(stock);
			} catch (NumberFormatException e) {
				// 文字が入力された場合のエラー設定
				error = "在庫数が不正の為、商品登録は行えませんでした。";
				cmd = "menu";
				return;
			}

			objUni = new Uniform();

			// 入力された情報をセッターメソッドでUniformオブジェクトに格納する
			objUni.setProductId(productId);
			objUni.setName(productName);
			objUni.setPrice(Integer.parseInt(price));
			objUni.setStock(Integer.parseInt(stock));
			objUni.setMaterial(material);
			objUni.setDetail(detail);
			objUni.setImagePath(imageName);

			// insertメソッドを利用して入力データを登録する
			uniformDao.insert(objUni);



		} catch (IllegalStateException e) {

			error = "DB接続エラーのため、商品登録処理は行えませんでした。";
			cmd ="menu";
			return;

		} catch (Exception e) {

			error = "想定外のエラー。";
			cmd ="logout";
			return;

		} finally {
			if (!error.equals("")) {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}else {
			// UniformListServletへフォワードする
			request.getRequestDispatcher("/uniformList").forward(request, response);
			}
		}
	}

}