package bean;

import java.sql.Timestamp;

public class User extends Address{

	// 氏名
	private String name;
	// 氏名（ふりがな）
	private String namePhonetic;
	// メール
	private String mail;
	// パスワード
	private String password;
	// 住所ID
	private int addressId;
	// 電話番号
	private String telephoneNumber;
	// 登録日
	private Timestamp registrationDate;
	// 更新日
	private Timestamp modifiedDate;
	// 削除フラグ
	private String deleteFlag;
	//権限
	private String authority;


	public User() {
		this.name = null;
		this.namePhonetic = null;
		this.mail = null;
		this.password = null;
		this.addressId = 0;
		this.telephoneNumber = null;
		this.deleteFlag = null;
	}

	public void setUserBlank() {

		setAddressBlank();

		this.name = "";
		this.namePhonetic = "";
		this.mail = "";
		this.password = "";
		this.addressId = 0;
		this.telephoneNumber = "";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNamePhonetic() {
		return namePhonetic;
	}

	public void setNamePhonetic(String namePhonetic) {
		this.namePhonetic = namePhonetic;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public Timestamp getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Timestamp registrationDate) {
		this.registrationDate = registrationDate;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}
}

