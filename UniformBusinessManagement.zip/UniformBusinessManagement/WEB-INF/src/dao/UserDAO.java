package dao;

import java.sql.*;
import java.util.ArrayList;

import bean.User;

public class UserDAO {

	//データベース接続情報
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL ="jdbc:mysql://localhost/uniformdb";
	private static String USER = "root";
	private static String PASS = "root123";

	//データベースに接続するメソッド
	private static Connection getConnection(){
		//例外をスロー
		try{
			//接続準備
			Class.forName(RDB_DRIVE);
			//接続
			Connection con = DriverManager.getConnection(URL,USER,PASS);
			return con; //Connectionクラスのオブジェクトを返す。
		}catch(Exception e){//想定外の例外処理
			throw new IllegalStateException(e);
		}
	}

	public ArrayList<User> selectAll() {

		ArrayList<User> userList = new ArrayList<User>();
		String sql = "SELECT * FROM users";

		Connection con = null;
		Statement smt = null;
		try {
			con = UserDAO.getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				User user = new User();
				user.setName(rs.getString("name"));
				user.setNamePhonetic(rs.getString("name_phonetic"));
				user.setMail(rs.getString("mail"));
				user.setPassword(rs.getString("password"));
				user.setAddressId(rs.getInt("address_id"));
				user.setTelephoneNumber(rs.getString("telephone_number"));
				user.setDeleteFlag(rs.getString("delete_flag"));

				userList.add(user);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return userList;

	}

	public User selectById(String mail) {

		Connection con = null;
		Statement smt = null;

		User user = new User();

		// SQL文
		String sql = "SELECT U.name, U.name_phonetic, U.mail, U.password, U.address_id, U.telephone_number, U.registration_date, U.modified_date,U.authority," +
				"A.zip_code, A.prefecture, A.municipalities, A.house_number, A.other" +
				" FROM users U LEFT JOIN addresses A on U.address_id = A.address_id WHERE mail='" + mail +"'";

		try {
			// Connectionオブジェクトの作成
			con = getConnection();
			// Statementオブジェクトの生成
			smt = con.createStatement();
			// SQL文の発行
			ResultSet rs = smt.executeQuery(sql);

			// Userオブジェクトに格納
			if (rs.next()) {
				user.setName(rs.getString("name"));
				user.setNamePhonetic(rs.getString("name_phonetic"));
				user.setMail(rs.getString("mail"));
				user.setPassword(rs.getString("password"));
				user.setAddressId(rs.getInt("address_id"));
				user.setRegistrationDate(rs.getTimestamp("registrationDate"));
				user.setModifiedDate(rs.getTimestamp("modified_date"));
				user.setTelephoneNumber(rs.getString("telephone_number"));
				user.setDeleteFlag(rs.getString("delete_flag"));
				user.setAuthority(rs.getString("authority"));

				user.setZipCode(rs.getString("zip_code"));
				user.setPrefecture(rs.getString("prefecture"));
				user.setMunicipalities(rs.getString("municipalities"));
				user.setHouseNumber(rs.getString("house_number"));
				user.setOther(rs.getString("other"));

			}else {
				user = null;
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return user;
	}

	public User selectByUser(String mail, String password) {

		Connection con = null;
		Statement smt = null;

		User user = new User();

		// SQL文
		String sql = "SELECT U.name, U.name_phonetic, U.mail, U.password, U.address_id, U.telephone_number, U.registration_date, U.modified_date, U.delete_flag, " +
				" U.Authority, A.zip_code, A.prefecture, A.municipalities, A.house_number, A.other " +
				"FROM users U LEFT JOIN addresses A on U.address_id = A.address_id WHERE U.mail='" + mail + "' AND U.password = '"+ password + "';";

		try {
			// Connectionオブジェクトの作成
			con = getConnection();
			// Statementオブジェクトの生成
			smt = con.createStatement();
			// SQL文の発行
			ResultSet rs = smt.executeQuery(sql);

			// Userオブジェクトに格納
			if (rs.next()) {
				user.setName(rs.getString("name"));
				user.setNamePhonetic(rs.getString("name_phonetic"));
				user.setMail(rs.getString("mail"));
				user.setPassword(rs.getString("password"));
				user.setAddressId(rs.getInt("address_id"));
				user.setTelephoneNumber(rs.getString("telephone_number"));
				user.setDeleteFlag(rs.getString("delete_flag"));
				user.setAuthority(rs.getString("authority"));

				user.setZipCode(rs.getString("zip_code"));
				user.setPrefecture(rs.getString("prefecture"));
				user.setMunicipalities(rs.getString("municipalities"));
				user.setHouseNumber(rs.getString("house_number"));
				user.setOther(rs.getString("other"));
			}else {
				user = null;
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return user;
	}

	public ArrayList<User> search(String name,String date) {

		Connection con = null;
		Statement smt = null;

		ArrayList<User> userList = new ArrayList<User>();

		String sql = "SELECT name,mail,telephone_number FROM users " + "WHERE name LIKE '%" + name
				+ "% AND telephone_number LIKE '%" + date + "%'";
		try {

			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				User user = new User();
				user.setName(rs.getString("name"));
				user.setMail(rs.getString("mail"));
				user.setTelephoneNumber(rs.getString("telephone_number"));

				userList.add(user);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return userList;
	}

	public void update(User user) {

		Connection con = null;
		Statement smt = null;

		// SQL
		String sql = "UPDATE users SET name='" + user.getName() + "',name_phonetic=" + user.getNamePhonetic()
				+ "',mail=" + user.getMail() + "',password=" + user.getPassword() + "',address_id="
				+ user.getAddressId() + "',telephone_number="+ user.getTelephoneNumber()
				+"modified_date = CURRENT_TIMESTAMP() WHERE user=" + user.getMail() + "'";

		try {
			// Connectionオブジェクトの作成
			con = getConnection();
			// Statementオブジェクトの生成
			smt = con.createStatement();
			// SQL文の発行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public void delete(String mail) {// 削除フラグを1にする

		Connection con = null;
		Statement smt = null;

		// SQL
		String sql = "UPDATE users SET delete_flag = '1'" + " WHERE mail=" + mail + "';";
		try {
			// Connectionオブジェクトの作成
			con = getConnection();
			// Statementオブジェクトの生成
			smt = con.createStatement();
			// SQL文の発行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public void insert(User user) {

		//操作用変数
		Connection con = null;
		Statement smt = null;

		try{ //例外をスロー
			con = getConnection(); //接続
			smt = con.createStatement(); //Statement作成

			//引数から登録用のSQL文作成
			String sql = "INSERT INTO addresses(address_id, zip_code, prefecture, municipalities, house_number, other)"
						+ " VALUES(NULL,'" + user.getZipCode() + "','" + user.getPrefecture() + "','" +
							user.getMunicipalities() + "','" + user.getHouseNumber() + "','" +
							user.getOther() + "')";

			smt.executeUpdate(sql);

			sql = "INSERT INTO users(name,name_phonetic,mail,password,address_id,telephone_number,registration_date,"
					+ "modified_date,delete_flag,authority)"
					+ " VALUES('" + user.getName() + "','" + user.getNamePhonetic() + "','" +
						user.getMail() + "','" + user.getPassword() + "',LAST_INSERT_ID(),'"
					+ user.getTelephoneNumber() +"',CURRENT_TIMESTAMP(),'0000-00-00 00:00:00','0','0')";

			//SQL文実行
			smt.executeUpdate(sql);

		}catch(Exception e){ //想定外の例外処理
			throw new IllegalStateException(e);
		}finally{ //必ずclose
			if( smt != null ){ //smtを解放
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){ //conを解放
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}
}
