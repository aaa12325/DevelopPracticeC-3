package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Order;
import bean.OrderedUniform;
import bean.Uniform;

public class UniformDAO {

	// JDBCドライバ内部のDriverクラスパス
	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	//接続するMySQLデータベースパス
	private static final String URL = "\"jdbc:mysql://localhost/uniformdb";
	//データベースのユーザー名
	private static final String USER = "root";
	//データベースのパスワード
	private static final String PASSWD = "root123";

	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	//全て選択
	public ArrayList<Uniform> selectAll() {
		Connection con = null;
		Statement smt = null;
		ArrayList<Uniform> uniformList = new ArrayList<Uniform>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT * FROM product_details ORDER BY product_id";
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Uniform uniform = new Uniform();
				uniform.setProductId(rs.getString("product_id"));
				uniform.setName(rs.getString("name"));
				uniform.setPrice(rs.getInt("price"));
				uniform.setMaterial(rs.getString("material"));
				uniform.setDetail(rs.getString("detail"));
				uniform.setImagePath(rs.getString("image_path"));
				uniform.setDeleteFlag(rs.getString("delete_flag"));

				uniformList.add(uniform);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return uniformList;
	}

	//登録
	public void insert(Uniform uniform) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "INSERT INTO product_details(product_id,name,price,material,detail,stock,image_path,"
					+ "registration_date,modified_date,delete_flag) VALUES('"+ uniform.getProductId() + "','"
					+ uniform.getName() + "','" + uniform.getPrice() + "','" + uniform.getMaterial() + "','"
					+ uniform.getDetail() + "','" + uniform.getStock() + "','" + uniform.getImagePath()+ "','" + uniform.getDeleteFlag() +")";

			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	//引数のproductIdを元に絞り込んで検索
	public Uniform selectByProductId(String productId) {
		Uniform uniform = new Uniform();
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql =  "SELECT * FROM product_details WHERE product_id = '" + productId + "'";
			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				uniform.setProductId(rs.getString("product_id"));
				uniform.setName(rs.getString("name"));
				uniform.setPrice(rs.getInt("price"));
				uniform.setMaterial(rs.getString("material"));
				uniform.setDetail(rs.getString("detail"));
				uniform.setImagePath(rs.getString("image_path"));
				uniform.setDeleteFlag(rs.getString("delete_flag"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return uniform;
	}

	//更新
	public void update(Uniform productId) {
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "UPDATE product_details SET name ='" + productId.getName() + "', price = '" + productId.getPrice()
					+ "',material = '" + productId.getMaterial() + "',detail = '" + productId.getDetail()
					+ "',image_path = '" + productId.getImagePath()
					+ "',modified_date = CURRENT_TIMESTAMP()"
					+ "' WHERE product_id = '" + productId.getProductId() + "'";
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	//削除
	public void delete(String productId) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "UPDATE product_details SET delete_flag='1' WHERE product_id='" + productId + "'";
			smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	//在庫変更
	public void updateStock(int stock, String productId) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "UPDATE product_details SET stock="+ stock + " WHERE product_id='" + productId + "'";
			smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	//注文時在庫減少
	public void decreaseStock(ArrayList<OrderedUniform> orderedUniformList) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "";

			for(int i=0; i < orderedUniformList.size(); i++) {
				OrderedUniform uniform = orderedUniformList.get(i);

				sql = "UPDATE product_details SET stock=stock -"+ uniform.getPurchaseNumber() + " WHERE product_id='" + uniform.getProductId() + "'";
				smt.executeUpdate(sql);
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	//
//	//引数の各データを元に絞り込んで検索
//	public ArrayList<Uniform> search(String productId,String name,String price) {
//		Connection con = null;
//		Statement smt = null;
//		ArrayList<Uniform> uniformList = new ArrayList<Uniform>();
//		try {
//			con = getConnection();
//			smt = con.createStatement();
//
//			String sql = "SELECT * FROM bookinfo WHERE isbn LIKE '%" + _isbn
//			+ "%' AND title LIKE '%" + _title + "%' AND price LIKE '%" + _price + "%'"
//
//			ResultSet rs = smt.executeQuery(sql);
//
//			while (rs.next()) {
//				Uniform uniform = new Uniform();
//				uniform.setProduct_id(rs.getInt("productId"));
//				uniform.setName(rs.getString("name"));
//				uniform.setPrice(rs.getInt("price"));
//				uniform.setMaterial(rs.getString("material"));
//				uniform.setDetail(rs.getString("detail"));
//				uniform.setImage_path(rs.getString("imagePath"));
//				uniform.setDelete_flag(rs.getString("deleteFlag"));
//			}
//		} catch (Exception e) {
//			throw new IllegalStateException(e);
//		} finally {
//			if (smt != null) {
//				try {
//					smt.close();
//				} catch (SQLException ignore) {
//				}
//			}
//			if (con != null) {
//				try {
//					con.close();
//				} catch (SQLException ignore) {
//				}
//			}
//		}
//		return uniformList;
//	}
}