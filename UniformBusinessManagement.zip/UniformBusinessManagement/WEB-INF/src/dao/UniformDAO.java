package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import bean.User;

//データベース接続情報
private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
private static String URL ="jdbc:mysql://localhost/uniformdb";
private static String USER = "root";
private static String PASS = "root123";

//データベースに接続するメソッド
private static Connection getConnection(){
	//例外をスロー
	try{
		//接続準備
		Class.forName(RDB_DRIVE);
		//接続
		Connection con = DriverManager.getConnection(URL,USER,PASS);
		return con; //Connectionクラスのオブジェクトを返す。
	}catch(Exception e){//想定外の例外処理
		throw new IllegalStateException(e);
	}
}

public void insert(User user) {

	//操作用変数
	Connection con = null;
	Statement smt = null;

	try{ //例外をスロー
		con = getConnection(); //接続
		smt = con.createStatement(); //Statement作成

		//引数から登録用のSQL文作成
		String sql = "INSERT INTO users(name,name_phonetic,mail,password,address_id,telephone_number,registration_date,"
					+ "modified_date,delete_flag,authority)"
					+ " VALUES('" + user.getName() + "','" + user.getNamePhonetic() + "','" +
						user.getMail() + "','" + user.getPassword() + "','" + user.getTelephoneNumber() +
						"',CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),'0','0')";
		//SQL文実行
		smt.executeUpdate(sql);

	}catch(Exception e){ //想定外の例外処理
		throw new IllegalStateException(e);
	}finally{ //必ずclose
		if( smt != null ){ //smtを解放
			try{smt.close();}catch(SQLException ignore){}
		}
		if( con != null ){ //conを解放
			try{con.close();}catch(SQLException ignore){}
		}
	}
}