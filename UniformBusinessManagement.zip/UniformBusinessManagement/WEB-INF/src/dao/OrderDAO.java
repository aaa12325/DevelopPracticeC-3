package dao;

import java.sql.*;
import java.util.ArrayList;

import bean.Address;
import bean.Order;
import bean.OrderedUniform;
import bean.User;
import util.SendMail;

public class OrderDAO {

	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost/uniformdb";
	private static final String USER = "root";
	private static final String PASSWD = "root123";

	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	//一覧表示用
	public ArrayList<Order> selectAll() {
		Connection con = null;
		Statement smt = null;
		ArrayList<Order> orderedList = new ArrayList<Order>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT U.name, U.name_phonetic, U.mail, U.password,U.telephone_number, " +
					"O.number, O.total_price, O.address_id, O.order_date, O.date_of_deposit, O.ship_date, O.payment_status, O.shipping_status, O.detail ,O.mail, "
					+ "O.modified_date, O.delete_flag " +
					"FROM order_histories O LEFT JOIN users U on U.mail = O.mail";

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				User user = new User();
				Order order = new Order();

				user.setName(rs.getString("name"));
				user.setNamePhonetic(rs.getString("name_phonetic"));
				order.setUser(user);

				order.setNumber(rs.getInt("number"));
				order.setTotalPrice(rs.getInt("total_price"));
				order.setAddressId(rs.getInt("O.address_id"));
				order.setOrderDate(rs.getTimestamp("order_date"));
				order.setDateOfDeposit(rs.getTimestamp("date_of_deposit"));
				order.setShipDate(rs.getTimestamp("ship_date"));
				order.setPaymentStatus(rs.getString("payment_status"));
				order.setShippingStatus(rs.getString("shipping_status"));
				order.setDetail(rs.getString("detail"));
				order.setModifiedDate(rs.getTimestamp("modified_date"));
				order.setDeleteFlag(rs.getString("delete_flag"));
				orderedList.add(order);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return orderedList;
	}

	//一覧表示用
	public Order selectById(String number) {
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT U.name, U.name_phonetic, U.mail, U.password, U.address_id, U.telephone_number, U.registration_date, U.modified_date," +
					"A.zip_code, A.prefecture, A.municipalities, A.house_number, A.other," +
					"O.number, O.total_price, O.address_id, O.order_date, O.date_of_deposit, O.ship_date, O.payment_status, O.shipping_status, O.detail, O.mail," +
					"O.delete_flag, P.product_id, P.name, P.price, P.material, P.detail, P.image_path, P.registration_date, P.modified_date," +
					"PU.number, PU.purchase_number " +
					"FROM order_histories AS O LEFT JOIN users AS U on U.mail = O.mail " +
					"LEFT JOIN addresses AS A on A.address_id = O.address_id " +
					"LEFT JOIN purchase_uniforms AS PU on O.number = PU.number " +
					"LEFT JOIN product_details AS P on P.product_id = PU.product_id "+
					"WHERE O.number='" + number + "';";

			ResultSet rs = smt.executeQuery(sql);

			Order order = new Order();
			ArrayList<OrderedUniform> orderedUniformList = new ArrayList<OrderedUniform>();

			if (rs.next()) {
				User user = new User();
				Address address = new Address();
				OrderedUniform uniform = new OrderedUniform();

				//ユーザー情報取得
				user.setName(rs.getString("U.name"));
				user.setNamePhonetic(rs.getString("name_phonetic"));
				user.setMail(rs.getString("U.mail"));
				//orderにセット
				order.setUser(user);

				//住所情報取得
				address.setZipCode(rs.getString("zip_code"));
				address.setPrefecture(rs.getString("prefecture"));
				address.setMunicipalities(rs.getString("municipalities"));
				address.setHouseNumber(rs.getString("house_number"));
				address.setOther(rs.getString("other"));
				//orderにセット
				order.setAddress(address);

				order.setNumber(rs.getInt("O.number"));
				order.setTotalPrice(rs.getInt("total_price"));
				order.setAddressId(rs.getInt("address_id"));
				order.setOrderDate(rs.getTimestamp("order_date"));
				order.setDateOfDeposit(rs.getTimestamp("date_of_deposit"));
				order.setShipDate(rs.getTimestamp("ship_date"));
				order.setPaymentStatus(rs.getString("payment_status"));
				order.setShippingStatus(rs.getString("shipping_status"));
				order.setDetail(rs.getString("detail"));
				order.setModifiedDate(rs.getTimestamp("modified_date"));
				order.setDeleteFlag(rs.getString("delete_flag"));

				do{
					uniform.setPurchaseNumber(rs.getInt("purchase_number"));
					uniform.setOrderNumber(rs.getInt("PU.number"));
					uniform.setName(rs.getString("P.name"));
					orderedUniformList.add(uniform);
				}while(rs.next());

				order.setOrderedUniformList(orderedUniformList);
			}
			else {
				order = null;
			}
			return order;

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public ArrayList<Order> selectByUser(String userMail) {
		//操作用変数
		Connection con = null;
		Statement smt = null;

		try{ //例外をスロー
			con = getConnection(); //接続
			smt = con.createStatement(); //Statement作成

			//引数から登録用のSQL文作成
			String sql = "SELECT U.name, U.name_phonetic, U.mail, U.password, U.address_id, U.telephone_number, U.registration_date, U.modified_date," +
					"O.number, O.total_price, O.address_id, O.order_date, O.date_of_deposit, O.ship_date, O.payment_status, O.shipping_status, O.detail, "
					+ "O.mail, O.delete_flag" +
					" FROM order_histories AS O LEFT JOIN users AS U on U.mail = O.mail " +
					"WHERE U.mail ='" + userMail + "';";

			//SQL文実行
			ResultSet rs = smt.executeQuery(sql);

			ArrayList<Order> orderList = new ArrayList<Order>();

			while (rs.next()) {
				User user = new User();
				Order order = new Order();

				user.setName(rs.getString("name"));
				order.setUser(user);

				order.setNumber(rs.getInt("number"));
				order.setTotalPrice(rs.getInt("total_price"));
				order.setAddressId(rs.getInt("address_id"));
				order.setOrderDate(rs.getTimestamp("order_date"));
				order.setDateOfDeposit(rs.getTimestamp("date_of_deposit"));
				order.setShipDate(rs.getTimestamp("ship_date"));
				order.setPaymentStatus(rs.getString("payment_status"));
				order.setShippingStatus(rs.getString("shipping_status"));
				order.setDetail(rs.getString("detail"));
				order.setModifiedDate(rs.getTimestamp("modified_date"));
				order.setDeleteFlag(rs.getString("delete_flag"));
				order.setMail(rs.getString("mail"));
				orderList.add(order);
			}

			return orderList;

		}catch(Exception e){ //想定外の例外処理
			throw new IllegalStateException(e);
		}finally{ //必ずclose
			if( smt != null ){ //smtを解放
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){ //conを解放
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}

	public void insert(Order order) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();

			Address address = order.getAddress();
			User user = order.getUser();
			ArrayList<OrderedUniform> uniformList = order.getOrderedUniformList();

			String sql = "INSERT INTO addresses(address_id, zip_code, prefecture, municipalities, house_number, other)"
						+ " VALUES(NULL,'" + address.getZipCode() + "','" + address.getPrefecture() + "','"
					     +address.getMunicipalities() + "','" + address.getHouseNumber() + "','"
						+ address.getOther() + "')";

			smt.executeUpdate(sql);

			sql = "INSERT INTO order_histories(number,total_price,address_id,order_date,date_of_deposit,"
					+ "ship_date,payment_status,shipping_status,detail,modified_date,mail,delete_flag) VALUES("
					+ "NULL," + order.getTotalPrice() + ",LAST_INSERT_ID()"
					+ ",CURRENT_TIMESTAMP(),'" + "1000-01-01 00:00:00" + "','"
					+ "1000-01-01 00:00:00" + "','" + "0" + "','"
					+ "0" + "','" + order.getDetail() + "',"
					+ "CURRENT_TIMESTAMP()" + ",'" + user.getMail() + "','0'" + ")";
			smt.executeUpdate(sql);

			for(OrderedUniform uniform:uniformList) {
				sql = "INSERT INTO purchase_uniforms(number,purchase_number,product_id) VALUES("
						+ "LAST_INSERT_ID(),'" + uniform.getPurchaseNumber() + "','" + uniform.getProductId() + "');";

				smt.executeUpdate(sql);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public void updatePayment(String payment,String number) {
		//操作用変数
		Connection con = null;
		Statement smt = null;

		try{ //例外をスロー
			con = getConnection(); //接続
			smt = con.createStatement(); //Statement作成

			//引数から登録用のSQL文作成
			String sql = "UPDATE order_histories SET payment_status='" + payment + "' WHERE number = '" + number + "';";
			//SQL文実行
			smt.executeUpdate(sql);


		}catch(Exception e){ //想定外の例外処理
			throw new IllegalStateException(e);
		}finally{ //必ずclose
			if( smt != null ){ //smtを解放
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){ //conを解放
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}

	public void updateShipping(String ship,String number) {
		//操作用変数
		Connection con = null;
		Statement smt = null;

		try{ //例外をスロー
			con = getConnection(); //接続
			smt = con.createStatement(); //Statement作成

			//引数から登録用のSQL文作成
			String sql = "UPDATE order_histories SET shipping_status='" + ship + "' WHERE number = '" + number + "';";
			//SQL文実行
			smt.executeUpdate(sql);

		}catch(Exception e){ //想定外の例外処理
			throw new IllegalStateException(e);
		}finally{ //必ずclose
			if( smt != null ){ //smtを解放
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){ //conを解放
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}

	public ArrayList<Order> search(String name, String date) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "SELECT O.number, O.total_price, O.address_id, O.order_date,"
					+ " O.paymentStatus, O.shippingStatus, O.delete_flag, U.name FROM order_histories AS O "
					+ "LEFT JOIN users as U on O.mail = U.mail"
					+ " WHERE date LIKE '%" + date + "%'AND deleteFlag LIKE '%" + name + ";";

			ResultSet rs = smt.executeQuery(sql);

			ArrayList<Order> orderList = new ArrayList<Order>();

			if (rs.next()) {
				Order order = new Order();
				order.setNumber(rs.getInt("number"));
				order.setTotalPrice(rs.getInt("total_prise"));
				order.setDateOfDeposit(rs.getTimestamp("date_of_deposit"));
				order.setPaymentStatus(rs.getString("payment_status"));
				order.setShippingStatus(rs.getString("shipping_Status"));
				order.setDeleteFlag(rs.getString("delete_flag"));
				orderList.add(order);
			}

			return orderList;

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
}