package dao;

import java.sql.*;
import java.util.ArrayList;
import bean.Order;

public class OrderDAO {

	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost/uniformdb";
	private static final String USER = "root";
	private static final String PASSWD = "root123";

	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public ArrayList<Ordered> selectAll() {
		Connection con = null;
		Statement smt = null;
		ArrayList<Order> orderedList = new ArrayList<Order>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT * FROM order_histories ORDER BY addressId DESC";
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Order order = new Order();
				order.setNumber(rs.getInt("number"));
				order.setTotal_price(rs.getInt("totalPrise"));
				order.setAddress_id(rs.getInt("addressId"));
				order.setOrder_date(rs.getString("orderDate"));
				order.setDate_of_deposit(rs.getString("dateOfDeposit"));
				order.setShip_date(rs.getString("shipDate"));
				order.setPayment_status(rs.getString("paymentStatus"));
				order.setShipping_status(rs.getString("shippingStatus"));
				order.setDetail(rs.getString("detail"));
				order.setModified_date(rs.getString("modifiedDate"));
				order.setDelete_flag(rs.getString("deleteFlag"));
				orderedList.add(order);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return orderedList;
	}

	public void insert(Order order) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "INSERT INTO uniformdb(number,totalPrise,addressId,orderDate,dateOfDeposit,shipDate,paymentStatus,shippingStatus,detail,modifiedDate,deleteFlag) VALUES('"
					+ order.getNumber() + "','" + order.getTotal_price() + "','" + order.getAddress_id()
					+ "','" + order.getOrder_date() + "','" + order.getDate_of_deposit() + "','"
					+ order.getShip_date() + "','" + order.getPayment_status() + "','"
					+ order.getShipping_status() + "','" + order.getDetail() + "','"
					+ order.getModified_date() + "','" + order.getDelete_flag() + ")";
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public ArrayList<Order> selectByName(String name, String date) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "SELECT O.number, O.total_price, O.address_id, O.order_date,"
					+ " O.paymentStatus, O.shippingStatus, U.name FROM order_histories AS O "
					+ "LEFT JOIN users as U on O.mail = U.mail"
					+ " WHERE date LIKE '%" + date + "%'AND deleteFlag LIKE '%" + name + ";";

			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				Order order = new Order();
				order.setNumber(rs.getInt("number"));
				order.setTotalPrice(rs.getInt("totalPrise"));
				order.setAddressId(rs.getInt("addressId"));
				order.setOrderDate(rs.getString("orderDate"));
				order.setDateOfDeposit(rs.getString("dateOfDeposit"));
				order.setShipDate(rs.getString("shipDate"));
				order.setPaymentStatus(rs.getString("paymentStatus"));
				order.setShippingStatus(rs.getString("shippingStatus"));
				order.setDetail(rs.getString("detail"));
				order.setModifiedDate(rs.getString("modifiedDate"));
				order.setDeleteFlag(rs.getString("deleteFlag"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order;
	}
}