package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Order;
import dao.UniformDAO;
import dao.UserDAO;

public class RestoreServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "menu";

		try {

			UniformDAO uniformDao = new UniformDAO();
			UserDAO userDao = new UserDAO();

			String productId = request.getParameter("product_id");
			String control = request.getParameter("control");

			uniformDao.restore(productId);


		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "logout";
		} catch (Exception e) {
			error = "想定外のエラー";
			cmd = "logout";
		} finally {
			// エラー有無フォワード
			if (error.equals("")) {
				// エラー無しlist.jspフォワード
				request.getRequestDispatcher("/view/allOrderList.jsp").forward(request, response);
			} else {
				// エラー有りerror.jspフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
