package servlet;

public class LogoutServlet {

}
