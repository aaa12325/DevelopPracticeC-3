/*プログラム名：UniformBusinessManagement
 * プログラムの説明：ログアウト処理用サーブレット
 * 作成日：6月23日
 * 作成者：長田麻由
 */
package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LogoutServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// 共通処理メソッドの呼び出し
		commonProcess(request, response);
	}

	// 共通処理メソッド
	private void commonProcess(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// セッションオブジェクトの生成
		HttpSession session = request.getSession();

		// セッション情報をクリアする
		session.invalidate();

		// menu.jsp(非会員画面)にフォワード
		request.getRequestDispatcher("view/menu.jsp").forward(request, response);
	}

}
