package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Order;
import bean.User;
import dao.OrderDAO;

public class MyOrderListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {
			User user = new User();
			OrderDAO objDao = new OrderDAO();

			ArrayList<Order> orderList = objDao.selectByUser(user.getMail());

			request.setAttribute("order_list", orderList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "menu";
		} finally {
			// エラー有無フォワード
			if (error.equals("")) {
				// エラー無しlist.jspフォワード
				request.getRequestDispatcher("/view/myOrderList.jsp").forward(request, response);
			} else {
				// エラー有りerror.jspフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
