package servlet;

public class InsertUniformServlet {

}
