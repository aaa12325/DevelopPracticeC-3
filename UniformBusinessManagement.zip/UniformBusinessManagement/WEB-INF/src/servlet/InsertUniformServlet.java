/* プログラム名：UniformBusinessManagement
 * プログラムの説明：新しく商品（ユニフォーム）を登録するサーブレット
 * 作成日：6月23日
 * 作成者：長田麻由
 *
 */
package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.Uniform;
import dao.UniformDAO;

public class InsertUniformServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// 入力情報を受け取るためのエンコードを行う
		request.setCharacterEncoding("UTF-8");

		String errorList = "";
		String errorMenu = "";
		String productId = request.getParameter("product_id");  //商品ID
		String productName = request.getParameter("product_name"); //商品名
		String price = request.getParameter("price"); //価格
		String stock = request.getParameter("stock"); //在庫数
		String material = request.getParameter("material"); //素材
		String detail = request.getParameter("detail"); //詳細説明
		String imagePath = request.getParameter("image_path"); //画像パス

		try {

			// UniformDAOオブジェクト宣言
			UniformDAO uniformDao = new UniformDAO();

			// ユニフォームの商品登録情報を格納するオブジェクト
			Uniform objUni =  uniformDao.selectByProductId(productId);




			// 入力チェック
			if (productId.equals("")) {
				errorList = "商品番号が未入力の為、商品登録処理は行えませんでした。";
				return;
			} else if (objUni.getProductId()!= null) {
				errorList = "入力商品番号は既に登録済みの為、商品登録処理は行えませんでした。";
				return;
			}else if (productName.equals("")) {
				errorList = "商品名が未入力の為、商品登録処理は行えませんでした。";
				return;
			}else if (price.equals("")) {
				errorList = "価格が未入力の為、商品登録処理は行えませんでした。";
				return;
			}else if (stock.equals("")){
				errorList = "在庫数が未入力の為、商品登録処理は行えませんでした。";
				return;
			}else if (material.equals("")){
				errorList = "素材が未入力の為、商品登録処理は行えませんでした。";
				return;
			}else if (imagePath.equals("")) {
				errorList = "画像パスが未選択の為、商品登録処理は行えませんでした。";
				return;
			}
			try {
				Integer.parseInt(price);
			} catch (NumberFormatException e) {
				// 文字が入力された場合のエラー設定
				errorList = "価格の値が不正の為、商品登録は行えませんでした。";
				return;
			}
			try {
				Integer.parseInt(stock);
			} catch (NumberFormatException e) {
				// 文字が入力された場合のエラー設定
				errorList = "在庫数が不正の為、商品登録は行えませんでした。";
				return;
			}



			// 入力された情報をセッターメソッドでUniformオブジェクトに格納する
			objUni.setProductId(productId);
			objUni.setName(productName);
			objUni.setPrice(Integer.parseInt(price));
			objUni.setStock(Integer.parseInt(stock));
			objUni.setMaterial(material);
			objUni.setDetail(detail);
			objUni.setImagePath(imagePath);

			// insertメソッドを利用して入力データを登録する
			uniformDao.insert(objUni);



		} catch (IllegalStateException e) {

			errorMenu = "DB接続エラーのため、商品登録処理は行えませんでした。";

		} finally {
			if (!errorList.equals("")) {
				request.setAttribute("error", errorList);
				request.setAttribute("cmd", "list");
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}else if (!errorMenu.equals("")) {
				request.setAttribute("error", errorMenu);
				request.setAttribute("cmd", "logout");
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}else {
			// UniformListServletへフォワードする
			request.getRequestDispatcher("/uniformList").forward(request, response);
			}
		}
	}

}