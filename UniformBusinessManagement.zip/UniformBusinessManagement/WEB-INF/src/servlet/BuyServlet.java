package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Address;
import bean.Order;
import bean.OrderedUniform;
import bean.User;
import dao.OrderDAO;
import dao.UserDAO;


public class BuyServlet extends HttpServlet{

	//getメソッド対応
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		//UTF-8で受け取る
		request.setCharacterEncoding("UTF-8");

		//エラー用
		String error = null;
		String cmd = "";

		try {

			HttpSession session = request.getSession();
			UserDAO userDao = new UserDAO();

			User user = (User)session.getAttribute("user");
			if(user == null) {

				user = new User();

				String name = request.getParameter("name");
				String namePhonetic = request.getParameter("namePhonetic");
				String mail = request.getParameter("mail");
				String phone = request.getParameter("phone");
				String zipCode = request.getParameter("zip_code");
				String prefecture = request.getParameter("prefecture");
				String municipalities = request.getParameter("municipalities");
				String houseNumber = request.getParameter("house_number");
				String other = request.getParameter("other");

				if(name.equals("")) {
					error = "名前が未入力です！";
					cmd = "menu";
					return;
				}
				if(phone.equals("")) {
					error = "電話番号が未入力です！";
					cmd = "menu";
					return;
				}
				if(namePhonetic.equals("")) {
					error = "ふりがなが未入力です！";
					cmd = "menu";
					return;
				}
				if(mail.equals("")) {
					error = "メールアドレスが未入力です！";
					cmd = "menu";
					return;
				}
				if(zipCode.equals("")) {
					error = "郵便番号が未入力です！";
					cmd = "menu";
					return;
				}
				if(prefecture.equals("")) {
					error = "都道府県が未入力です！";
					cmd = "menu";
					return;
				}
				if(municipalities.equals("")) {
					error = "市区町村が未入力です！";
					cmd = "menu";
					return;
				}
				if(houseNumber.equals("")) {
					error = "番地が未入力です！";
					cmd = "menu";
					return;
				}

				if(userDao.selectById(mail) != null) {
					error = "このメールアドレスは既に会員登録に用いられています。";
					cmd = "menu";
					return;
				}

				user.setName(name);
				user.setNamePhonetic(namePhonetic);
				user.setMail(mail);


				user.setTelephoneNumber(phone);
				user.setZipCode(zipCode);
				user.setPrefecture(prefecture);
				user.setMunicipalities(municipalities);
				user.setHouseNumber(houseNumber);
				user.setOther(other);

				new UserDAO().insert(user);
			}

			ArrayList<OrderedUniform> uniformList = (ArrayList<OrderedUniform>)session.getAttribute("order_list");
			int totalPrice = 0;

			for(int i = 0; i < uniformList.size(); i++) {
				totalPrice += uniformList.get(i).getPrice();
			}

			Address address = new Address();
			address.setZipCode(request.getParameter("zip_code"));
			address.setPrefecture(request.getParameter("prefecture"));
			address.setMunicipalities(request.getParameter("municipalities"));
			address.setHouseNumber(request.getParameter("house_number"));
			address.setOther(request.getParameter("other"));

			Order order = new Order();

			order.setTotalPrice(totalPrice);
			order.setAddress(address);
			order.setUser(user);
			order.setOrderedUniformList(uniformList);

			new OrderDAO().insert(order);

			request.setAttribute("order", order);

		}catch(IllegalStateException e) {
			error = "DB接続エラー";
			cmd = "logout";
		}catch(Exception e) {
			error = "想定外のエラー";
			cmd = "logout";
		}
		finally {
			if(error != null) { //エラー時
				request.setAttribute("error",error); //エラーメッセージ登録
				request.setAttribute("cmd",cmd); //リンクの種類登録
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);//エラーページにフォワード
			}else { //エラーなし
				request.getRequestDispatcher("/view/buyConfirm.jsp").forward(request, response); //詳細表示
			}
		}
	}
}

