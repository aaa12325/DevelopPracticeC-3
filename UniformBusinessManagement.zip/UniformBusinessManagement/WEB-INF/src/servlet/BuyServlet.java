package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Address;
import bean.Order;
import bean.OrderedUniform;
import bean.User;
import dao.OrderDAO;
import dao.UserDAO;


public class BuyServlet extends HttpServlet{

	//getメソッド対応
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		//UTF-8で受け取る
		request.setCharacterEncoding("UTF-8");

		//エラー用
		String error = null;
		String cmd = "";

		try {

			HttpSession session = request.getSession();

			User user = (User)session.getAttribute("user");
			if(user == null) {
				user = (User)request.getAttribute("user"); //仮
				new UserDAO().insert(user);
			}

			ArrayList<OrderedUniform> uniformList = (ArrayList<OrderedUniform>)session.getAttribute("order_list");

			Address address = new Address();
			address.setZipCode(request.getParameter("zip_code"));
			address.setPrefecture(request.getParameter("prefecture"));
			address.setMunicipalities(request.getParameter("municipalities"));
			address.setHouseNumber(request.getParameter("house_number"));
			address.setOther(request.getParameter("other"));

			Order order = new Order();

			order.setAddress(address);
			order.setUser(user);
			order.setOrderedUniformList(uniformList);

			new OrderDAO().insert(order);

			request.setAttribute("order", order);

		}catch(IllegalStateException e) {
			error = "DB接続エラー。";
			cmd = "logout";
		}catch(Exception e) {
			error = "想定外のエラー";
			cmd = "logout";
		}
		finally {
			if(error != null) { //エラー時
				request.setAttribute("error",error); //エラーメッセージ登録
				request.setAttribute("cmd",cmd); //リンクの種類登録
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);//エラーページにフォワード
			}else { //エラーなし
				request.getRequestDispatcher("/view/buyConfirm.jsp").forward(request, response); //詳細表示
			}
		}
	}
}

