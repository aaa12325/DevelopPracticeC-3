package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Uniform;
import dao.UniformDAO;

public class UniformListServlet extends HttpServlet {

	//getメソッド対応
		public void doGet(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

			//共通処理
			list(request,response);

		}

		//getメソッド対応
		public void doPost(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

			//共通処理
			list(request,response);

		}

		private void list(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

			//エラー用
			String error = null;
			String cmd = "list";

			try {
				ArrayList<Uniform> uniformList = new UniformDAO().selectAll(); //全件検索
				request.setAttribute("uniformList",uniformList); //リクエストスコープに格納



			}catch(IllegalStateException e) {
				error = "DB接続エラーの為、一覧表示は行なえませんでした。 ";
				cmd = "logout";
			}catch(Exception e) {
				error = "想定外のエラー";
				cmd = "logout";
			}
			finally {
				if(error != null) { //エラーがある時
					request.setAttribute("error",error); //エラーメッセージ登録
					request.setAttribute("cmd",cmd); //リンクの種類登録
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);//フォワード
				}else { //エラーがない場合
					request.getRequestDispatcher("/view/uniformList.jsp").forward(request, response); //フォワード
				}
			}
		}

}
