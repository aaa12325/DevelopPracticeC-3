package servlet;

public class UniformListServlet {

}
