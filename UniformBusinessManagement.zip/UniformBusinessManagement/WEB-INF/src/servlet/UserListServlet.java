package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class UserListServlet extends HttpServlet {

	// getメソッド
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// 共通処理
		list(request, response);
	}

	// postメソッド
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// 共通処理
		list(request, response);
	}

	// 共通処理
	private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラー用の変数
		String error = "";
		String cmd = null;

		try {
			// 全件検索
			ArrayList<User> userlist = new UserDAO().selectAll();
			// 取得リストをuserlistで登録
			request.setAttribute("userlist", userlist);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行なえませんでした。 ";
			cmd = "logout";
		} catch (Exception e) {
			error = "想定外のエラー";
			cmd = "logout";
		} finally {
			if (!error.equals("")) { // エラー時
				request.setAttribute("error", error); // エラーメッセージ登録
				request.setAttribute("cmd", cmd); // リンクの種類登録
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);// errorへフォワード
			} else { // エラーなし
				request.getRequestDispatcher("/view/userList.jsp").forward(request, response); // userlistへフォワード
			}
		}
	}
}
