package servlet;

public class DetailUniformServlet {

}
