package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Uniform;
import dao.UniformDAO;

public class DetailUniformServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			// isbnとcmd(フォワード先を区別するパラメータ)を取得
			String productId = request.getParameter("productId");
			cmd = request.getParameter("cmd");

			// UniformDAOをオブジェクト化
			UniformDAO uniDao = new UniformDAO();

			// 商品情報を検索し、戻り値としてuniformオブジェクトを取得
			Uniform uniform = uniDao.selectByProductId(productId);

			// 詳細情報のエラーチェック
			if (uniform == null) {
				error = "表示対象の商品が存在しない為、詳細情報は表示出来ませんでした。";
				cmd = "list";
			}

			// 取得した情報をuniformの名前で送る
			request.setAttribute("uniform", uniform);

		} catch (IllegalStateException e) {
			if (cmd.equals("detail")) {
				error = "DB接続エラーの為、商品詳細は表示出来ませんでした。";
			} else if (cmd.equals("update")) {
				error = "DB接続エラーの為、変更画面は表示できませんでした。";
			}
			cmd = "menu";
		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// cmdの値でフォワード先を呼び分ける
				if (cmd.equals("detail")) {
					request.getRequestDispatcher("/view/detailUniform.jsp").forward(request, response);
				} else if (cmd.equals("update")) {
					request.getRequestDispatcher("/view/updateUniform.jsp").forward(request, response);
				}
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}
		}
	}
}
