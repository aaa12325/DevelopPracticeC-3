/*プログラム名：UniformBusinessManagement
 * プログラムの説明：ログイン処理用サーブレット
 * 作成日：6月23日
 * 作成者：長田麻由
 */
package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class LoginServlet extends HttpServlet {

	public void doPost (HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		String error ="";


		//セッションオブジェクトの生成
		HttpSession session = request.getSession();

		try {
			//パラメーターの取得
			String userid = request.getParameter("userid");
			String password = request.getParameter("password");

			//Userのオブジェクト化
			User user = new User();

			//UserDAOのオブジェクト化
			UserDAO userDao = new UserDAO();

			//ユーザ情報を取得するメソッドの呼び出し
			user = userDao.selectByUser(userid, password);

			if(user.getDeleteFlag().equals("1")) {
				error = "会員情報は削除されています。";
				return;
			}

			//入力したユーザー情報がデータベースの情報が同じだった場合
			if(user != null) {
				//セッションスコープに登録
				session.setAttribute("user", user);
				//クッキー登録
				Cookie userCookie = new Cookie("userid",userid);
				//クッキーの期限は5日間にする
				userCookie.setMaxAge(60*60*24*5);
				response.addCookie(userCookie);

				Cookie passCookie = new Cookie("password",password);
				passCookie.setMaxAge(60*60*24*5);
				response.addCookie(passCookie);

			}//入力したユーザー情報がデータベースの情報が違う場合
			else {
				error ="入力データが間違っています。";
				request.setAttribute("error", error);
				//ログイン画面にフォワードしエラーメッセージを表示
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
				return;
			}


		} catch (IllegalStateException e) {
			error ="DB接続エラーのため、ログインできません。";
		} catch (Exception e) {
			error ="予期せぬエラーが発生しました。";
		} finally {
			if (error.equals("")) {
				//menu.jspにフォワード
				request.getRequestDispatcher("/view/menu.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", "logout");
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}

}
