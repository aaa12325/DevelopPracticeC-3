package servlet;

public class BuyServletServlet {

}
