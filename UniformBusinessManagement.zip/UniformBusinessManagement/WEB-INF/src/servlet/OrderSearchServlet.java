package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Order;
import dao.OrderDAO;

public class OrderSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {

			request.setCharacterEncoding("UTF-8");

			// 名前と日付入力取得
			String name = request.getParameter("name");

			OrderDAO objDao = new OrderDAO();

			// 検索メソッド呼び出し
			ArrayList<Order> orderList = objDao.search(name);

			request.setAttribute("order_list", orderList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "menu";

		} finally {
			// エラー有無フォワード
			if (error.equals("")) {
				// エラー無しlist.jspフォワード
				request.getRequestDispatcher("/view/allOrderList.jsp").forward(request, response);
			} else {
				// エラー有りerror.jspフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
