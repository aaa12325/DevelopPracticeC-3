package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;


public class DetailUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";
		String cmdDetail = "";

		try {

			request.setCharacterEncoding("UTF-8");

			// mail、cmd取得
			String mail = request.getParameter("mail");
			cmdDetail = request.getParameter("cmd");

			UserDAO objDao = new UserDAO();

			// 会員情報検索
			User user = objDao.selectById(mail);

			// 詳細情報エラーチェック
			if (user.getMail() == null) {
				error = "表示対象の会員情報が存在しない為、詳細情報は表示出来ませんでした。";
				cmd = "list";
			}

			request.setAttribute("user", user);

		} catch (IllegalStateException e) {
			if (cmdDetail.equals("detail")) {
				error = "DB接続エラーの為、会員情報詳細は表示出来ませんでした。";
				cmd = "logout";
			} else if (cmdDetail.equals("update")) {
				error = "DB接続エラーの為、変更画面は表示できませんでした。";
				cmd = "logout";
			}
			cmd = "menu";
		} finally {
			// エラー有無フォワード
			if (error.equals("")) {
				// cmd値でフォワード
				if (cmdDetail.equals("detail")) {
					request.getRequestDispatcher("/view/detailUser.jsp").forward(request, response);
				} else if (cmdDetail.equals("update")) {
					request.getRequestDispatcher("/view/updateUser.jsp").forward(request, response);
				}
			} else {
				// エラー有りerror.jspフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);

			}
		}

	}
}
