package servlet;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Uniform;
import dao.UniformDAO;

public class DeleteUniformServlet extends HttpServlet{
	//getメソッド対応
			public void doGet(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

				//共通処理
				delete(request,response);

			}

			//getメソッド対応
			public void doPost(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

				//共通処理
				delete(request,response);

			}

			private void delete(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

				//エラー用
				String error = "";
				String cmd = "list";

				try {

					// 入力データの文字コードの指定
					request.setCharacterEncoding("UTF-8");

					// 画面から送信される情報を受け取る
					int productId = Integer.parseInt(request.getParameter("productId"));

					// DAOクラスのオブジェクトの生成
					UniformDAO uniformDao = new UniformDAO();

					//データ格納用のuniformオブジェクトを生成
					Uniform uniform = uniformDao.selectByProductId(productId);

					// 確認

					if (uniform == null) {
						error = "削除対象の商品が存在しない為、商品削除処理は行えませんでした。";
						cmd = "list";
						return;
					}

					uniformDao.delete(productId);


				}catch(IllegalStateException e) {
					error = "DB接続エラーの為、一覧表示は行なえませんでした。 ";
					cmd = "logout";
				}catch(Exception e) {
					error = "想定外のエラー";
					cmd = "logout";
				}
				finally {
					if(!error.equals("")) { //エラーがある時
						request.setAttribute("error",error); //エラーメッセージ登録
						request.setAttribute("cmd",cmd); //リンクの種類登録
						request.getRequestDispatcher("/view/error.jsp").forward(request, response);//フォワード
					}else { //エラーがない場合
						request.getRequestDispatcher("/uniformList").forward(request, response); //フォワード
					}
				}
			}
}