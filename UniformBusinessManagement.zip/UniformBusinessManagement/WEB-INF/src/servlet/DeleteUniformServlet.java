package servlet;

public class DeleteUniformServlet {

}
