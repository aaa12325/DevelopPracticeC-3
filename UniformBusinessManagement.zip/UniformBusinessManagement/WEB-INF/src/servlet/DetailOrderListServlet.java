package servlet;

public class DetailOrderListServlet {

}
