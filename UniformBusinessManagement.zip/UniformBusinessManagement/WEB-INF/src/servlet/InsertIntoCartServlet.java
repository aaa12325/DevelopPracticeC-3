package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Address;
import bean.Order;
import bean.OrderedUniform;
import bean.Uniform;
import bean.User;
import dao.UniformDAO;

public class InsertIntoCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {
			//　セッションからuserオブジェクトを取得
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			//　セッション切れ
			if (user == null) {

			}

			//個数のパラメータを入れる
			int purchaseNumber = 0;
			try {
				purchaseNumber =Integer.parseInt(request.getParameter("purchaseNumber"));
			}catch(NumberFormatException e) {
				error="入力された文字列が数値ではありませんでした。";
				cmd="list";
				return;
			}

			// productIdのパラメータを取得
			String productId = (String) request.getParameter("productId");
			String stock = (String) request.getParameter("purchaseNumber");

			// UniformDAOをインスタンス化し、商品情報の検索
			OrderedUniform orderedUniform = new OrderedUniform();
			UniformDAO uniDao = new UniformDAO();
			Uniform uniform = uniDao.selectByProductId(productId);

			// UniformをOrderedUniformに入れる
			orderedUniform.setProductId(uniform.getProductId());
			orderedUniform.setPrice(uniform.getPrice());
			orderedUniform.setName(uniform.getName());
			orderedUniform.setMaterial(uniform.getMaterial());
			orderedUniform.setImagePath(uniform.getImagePath());
			orderedUniform.setDetail(uniform.getDetail());
			orderedUniform.setPurchaseNumber(Integer.parseInt(stock));

			//　カートを取得
			ArrayList<OrderedUniform> list = (ArrayList<OrderedUniform>)session.getAttribute("order_list");
			if(list == null) { //　一つ目の注文の場合
				list = new ArrayList<OrderedUniform>(); //　リストを作る
			}

			//　同じ商品がカートにあるかどうか
			for(OrderedUniform oneOrder:list) {
				if(oneOrder.getProductId().equals(productId)){ //　あった場合

					//　加算
					oneOrder.plusPurchase(purchaseNumber);

					request.setAttribute("uniform", orderedUniform);

					//　カートの中身をセッションに登録
					session.setAttribute("order_list",list);
					return;
				}
			}

			request.setAttribute("uniform", orderedUniform);
			list.add(orderedUniform);
			session.setAttribute("order_list", list);


		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、カートに追加は出来ません。";
			cmd = "logout";
		} finally {
			//　エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				//　エラーが無い場合はinsertIntoCart.jspにフォワード
				request.getRequestDispatcher("/view/insertIntoCart.jsp").forward(request, response);
			} else {
				//　エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
