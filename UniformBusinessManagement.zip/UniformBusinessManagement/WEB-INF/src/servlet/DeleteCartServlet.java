package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.OrderedUniform;
import dao.OrderDAO;
import dao.UniformDAO;

public class DeleteCartServlet extends HttpServlet{
	//getメソッド対応
			public void doGet(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

				//共通処理
				delete(request,response);

			}

			//getメソッド対応
			public void doPost(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

				//共通処理
				delete(request,response);

			}

			private void delete(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{

				//エラー用
				String error = null;
				String cmd = "list";

				try {

					// 入力データの文字コードの指定
					request.setCharacterEncoding("UTF-8");

					// 画面から送信される情報を受け取る
					String productId = (String) request.getParameter("productId");

					HttpSession session = request.getSession();

					ArrayList<OrderedUniform> uniformList = (ArrayList<OrderedUniform>)session.getAttribute("order_list");

					for(int i = 0; i < uniformList.size(); i++) {
						if(productId.equals(uniformList.get(i).getProductId())) {
							uniformList.remove(i);
							break;
						}
					}

					session.setAttribute("order_list", uniformList);

				}catch(IllegalStateException e) {
					error = "DB接続エラーの為、一覧表示は行なえませんでした。 ";
					cmd = "logout";
				}catch(Exception e) {
					error = "想定外のエラー";
					cmd = "logout";
				}
				finally {
					if(error != null) { //エラーがある時
						request.setAttribute("error",error); //エラーメッセージ登録
						request.setAttribute("cmd",cmd); //リンクの種類登録
						request.getRequestDispatcher("/view/error.jsp").forward(request, response);//フォワード
					}else { //エラーがない場合
						request.getRequestDispatcher("/view/cartList.jsp").forward(request, response); //フォワード
					}
				}
			}
}