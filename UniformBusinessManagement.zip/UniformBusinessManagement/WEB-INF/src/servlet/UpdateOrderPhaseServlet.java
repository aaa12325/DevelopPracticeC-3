package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Order;
import dao.OrderDAO;

public class UpdateOrderPhaseServlet extends HttpServlet{

	//getメソッド対応
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		//UTF-8で受け取る
		request.setCharacterEncoding("UTF-8");

		//エラー用
		String error = null;
		String cmd = "menu";

		try {

			OrderDAO orderDao = new OrderDAO();

			//更新内容取得
			String phaseNumber = request.getParameter("payment");
			String number = request.getParameter("number");

			if(phaseNumber == null) {
				phaseNumber = request.getParameter("ship");
				orderDao.updateShipping(phaseNumber,number);
				return;
			}

			orderDao.updatePayment(phaseNumber,number);
			return;

		}catch(IllegalStateException e) {
			error = "DB接続エラー。";
			cmd = "logout";
		}catch(Exception e) {
			error = "想定外のエラー";
			cmd = "logout";
		}
		finally {
			if(error != null) { //エラー時
				request.setAttribute("error",error); //エラーメッセージ登録
				request.setAttribute("cmd",cmd); //リンクの種類登録
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);//エラーページにフォワード
			}else { //エラーなし
				request.getRequestDispatcher("/allOrderList").forward(request, response); //詳細表示
			}
		}
	}
}
