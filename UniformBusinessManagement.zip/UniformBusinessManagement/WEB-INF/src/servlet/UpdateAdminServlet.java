package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;

import dao.UserDAO;

public class UpdateAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {

			request.setCharacterEncoding("UTF-8");

			// id,password取得
			String id = request.getParameter("id");
			String password = request.getParameter("password");
			String passwordC = request.getParameter("passwordC");

			// 空白チェック
			if (id.equals("")) {
				error = "ユーザーIDが未入力の為、管理者情報の更新処理は行えませんでした。";
				cmd = "menu";
				return;
			}
			if (password.equals("")) {
				error = "パスワードが未入力の為、管理者情報の更新処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			UserDAO userDao = new UserDAO();
			User user = userDao.selectById(id);

			// ユーザーチェック
			if (user == null) {
				error = "更新対象が存在しない為、管理者情報の更新処理は行えませんでした。";
				cmd = "logout";
				return;
			}

			// パスワード一致確認
			if (!password.equals(passwordC)) {
				error = "入力されたパスワードが一致しない為、管理者情報の更新処理は行えませんでした。";
				cmd = "logout";
				return;
			}


			user.setMail(id);
			user.setPassword(password);

			// 更新メソッド呼び出し
			userDao.update(user);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、管理者情報の更新処理は行えませんでした。";
			cmd = "menu";
		} catch (Exception e) {
			error = "DB接続エラーの為。";
			cmd = "menu";
		} finally {
			// エラー有無フォワード
			if (error.equals("")) {
				// エラー無しListServletフォワード
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			} else {
				// エラー有りerror.jspフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}