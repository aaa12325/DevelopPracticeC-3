package servlet;

public class UpdateAdminServlet {

}
