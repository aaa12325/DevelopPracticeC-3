package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Order;
import bean.OrderedUniform;
import bean.User;
import dao.OrderDAO;


public class CartListServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			HttpSession session = request.getSession();

			OrderDAO objDao = new OrderDAO();

			//戻り値としてOrderオブジェクトのリストを取得
			ArrayList<OrderedUniform>orderList = (ArrayList<OrderedUniform>)session.getAttribute("order_list");

			//リクエストスコープに"order_list"という名前で格納する
			request.setAttribute("order_list",orderList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、カート一覧は確認出来ません。";
			cmd = "logout";

		} finally {
			// エラー有無フォワード
			if (error.equals("")) {
				//エラーが無い場合はlist.jspにフォワード
				request.getRequestDispatcher("/view/cartList.jsp").forward(request, response);
			} else {
				//エラーがある場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
