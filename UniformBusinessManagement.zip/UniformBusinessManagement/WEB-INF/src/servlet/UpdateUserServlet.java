/*プログラム名：UniformBusinessManagement
 * プログラムの説明：会員情報更新機能を作成します。
 * 作成日：6月24日
 * 作成者：長田麻由
 */
package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class UpdateUserServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// 入力情報を受け取る為のエンコードを設定
		request.setCharacterEncoding("UTF-8");

		String error = "";
		String cmd = "menu";

		try {
			// パラメーターの取得
			String userName = request.getParameter("userName"); // ユーザーの名前
			String namePhonetic = request.getParameter("namePhonetic"); // 名前のかな
			String mail = request.getParameter("mail"); // メールアドレス
			String password = request.getParameter("pass"); // パスワード
			String passConfirm = request.getParameter("passConfirm"); // 確認用パスワード
			String zipCode = request.getParameter("zipCode"); // 郵便番号
			String prefecture = request.getParameter("prefecture"); // 都道府県
			String municipalities = request.getParameter("municipalities"); // 市区町村
			String houseNum = request.getParameter("houseNumber"); // 町名・番地
			String other = request.getParameter("other"); // その他建物名
			String telNum = request.getParameter("telephoneNum"); // 電話番号

			// UniformDAOオブジェクトの生成
			UserDAO objUser = new UserDAO();

			// 更新後のユーザー情報を格納するuserオブジェクトを生成
			User user = new User();

			// 入力チェック

			User oldUser = objUser.selectById(mail);

			if(oldUser == null) {
				error = "ユーザーが存在しないためユーザー情報を更新できません。";
				cmd = "logout";
				return;
			}

			if (userName.equals("")) {
				error = "氏名が未入力の為、会員情報変更は行えませんでした。";
				cmd = "menu";
				return;
			} else if (namePhonetic.equals("")) {
				error = "氏名（かな）が未入力の為、会員情報変更は行えませんでした。";
				cmd = "menu";
				return;
			} else if (mail.equals("")) {
				error = "メールアドレスが未入力の為、会員情報変更は行えませんでした。";
				cmd = "menu";
				return;
			} else if (password.equals("")) {
				error = "パスワードが未入力の為、会員情報変更は行えませんでした。";
				cmd = "menu";
				return;
			} else if (!password.equals(passConfirm)) {
				error = "確認用パスワードが一致しません。";
				cmd = "menu";
				return;
			} else if (zipCode.equals("")) {
				error = "郵便番号が未入力の為、会員情報変更は行えませんでした。";
				cmd = "menu";
				return;
			} else if (prefecture.equals("")) {
				error = "都道府県が未入力の為、会員情報変更は行えませんでした。";
				cmd = "menu";
				return;
			} else if (municipalities.equals("")) {
				error = "市区町村が未入力の為、会員情報変更は行えませんでした。";
				cmd = "menu";
				return;
			} else if (houseNum.equals("")) {
				error = "町名・番地が未入力の為、会員情報変更は行えませんでした。";
				cmd = "menu";
				return;
			} else if (telNum.equals("")) {
				error = "電話番号が未入力の為、会員情報変更は行えませんでした。";
				cmd = "menu";
				return;
			}

			int addressId = oldUser.getAddressId();

			// 住所情報を受け取るuserオブジェクトに格納

			user.setAddressId(addressId);
			user.setZipCode(zipCode);
			user.setPrefecture(prefecture);
			user.setMunicipalities(municipalities);
			user.setHouseNumber(houseNum);
			user.setOther(other);

			// ユーザー情報を受け取るuserオブジェクトに格納
			user.setName(userName);
			user.setNamePhonetic(namePhonetic);
			user.setMail(mail);
			user.setPassword(password);
			user.setTelephoneNumber(telNum);
			user.setAuthority("0");
			// updateメソッドを利用してユーザー情報を更新
			objUser.update(user);

			user = objUser.selectById(mail);

			request.setAttribute("user",user);

			HttpSession session = request.getSession();
			session.setAttribute("user", user);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、書籍更新処理は行えませんでした。";
			cmd = "menu";
		} catch (Exception e) {
			error = "想定外のエラー";
			cmd = "menu";

		} finally {
			if(!error.equals("")) { //エラー時
				request.setAttribute("error",error); //エラーメッセージ登録
				request.setAttribute("cmd",cmd); //リンクの種類登録
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);//エラーページにフォワード
			}else { //エラーなし
				request.getRequestDispatcher("/view/detailUser.jsp").forward(request, response); //詳細表示
			}
		}
	}

}