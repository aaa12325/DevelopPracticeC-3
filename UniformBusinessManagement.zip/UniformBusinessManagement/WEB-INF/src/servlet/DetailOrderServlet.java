package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Order;
import dao.OrderDAO;


public class DetailOrderServlet  extends HttpServlet{

	//getメソッド対応
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException,IOException{

		//UTF-8で受け取る
		request.setCharacterEncoding("UTF-8");

		//エラー用
		String error = null;
		String cmd = "menu";

		try {
			//注文番号取得
			String orderNumber = request.getParameter("number");

			//問い合わせ番号からレコードを取得
			Order order = new OrderDAO().selectById(orderNumber);

			request.setAttribute("order", order);

		}catch(IllegalStateException e) {
			error = "DB接続エラーです！";
			cmd = "logout";
		}catch(Exception e) {
			error = "想定外のエラー";
			cmd = "logout";
		}
		finally {
			if(error != null) { //エラー時
				request.setAttribute("error",error); //エラーメッセージ登録
				request.setAttribute("cmd",cmd); //リンクの種類登録
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);//エラーページにフォワード
			}else { //エラーなし
				request.getRequestDispatcher("/view/detailOrder.jsp").forward(request, response); //詳細表示
			}
		}
	}
}
