package servlet;

import java.io.*;


import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class DeleteUserServlet extends HttpServlet {
	// getメソッド
	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// 共通処理
		delete(request, response);
	}

	// postメソッド
	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// 共通処理
		delete(request, response);
	}

	// 共通処理
	private void delete(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {

		// セッションオブジェクトの生成
		HttpSession session = request.getSession();
		// エラー用の変数
		String error = "";
		String cmd = null;

		//リクエストスコープから権限の情報を取得
		String authority = request.getParameter("authority");

		//リクエストスコープからIDとパスワードを取得
		String userId = request.getParameter("ID");
		String pass = request.getParameter("pass");


		try {
			// セッションからuserを取得する
			User user = (User) session.getAttribute("user");
			if (user == null) {
				error = "セッション切れの為、処理は行えませんでした。";
				request.setAttribute("cmd", "logout");
				return;
			}
			// UserDAOオブジェクトの作成
			UserDAO userDAO = new UserDAO();

			// 権限が管理者のとき
			if (authority.equals("master")) {

				//IDとパスワードを引数に該当する管理者の会員情報を格納する
				User masterUser = userDAO.selectByUser(userId, pass);

				//入力したユーザー情報がデータベースの情報と違う場合
				if(masterUser == null) {
					error ="入力データが間違っています。";
					request.setAttribute("error", error);
					cmd ="menu";
					return;
				}
				//会員情報のメールアドレスを取得
				String mail = request.getParameter("mail");
				//会員情報をUserに格納
				User userDetail = userDAO.selectById(mail);

				//会員情報の削除フラグを変更する
				userDAO.delete(mail);

			} else if(authority.equals("member")) {
				// 表示対象の会員情報があるか確認
				if (userDAO.selectById(userId) == null) {
					error = "削除対象の会員が存在しない為、会員削除処理は行えませんでした。";
					cmd = "list";
					return;
				}
				//IDとパスワードを引数に該当する会員情報を格納する
				User memberUser = userDAO.selectByUser(userId, pass);

				//入力した情報と異なる場合
				if(memberUser == null) {
					error = "入力データが間違っています。";
					cmd = "menu";
					return;
				}
				//会員情報の削除フラグを変更する
				userDAO.delete(userId);
			}


		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、処理は行えませんでした。 ";
			cmd = "logout";
		} catch (Exception e) {
			error = "予期せぬエラーが発生しました。";
			cmd = "logout";
		} finally {
			if (!error.equals("")) {// エラーがある時
				request.setAttribute("error", error); // エラーメッセージ登録
				request.setAttribute("cmd", cmd); // リンクの種類登録
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);// errorへフォワード
			}else if(error.equals("")&&authority.equals("master") ){ // エラーがない場合かつ管理者
				request.getRequestDispatcher("/userList").forward(request, response); // 会員一覧へフォワード
			}else if (error.equals("")&&authority.equals("member")) {// エラーがない場合かつ一般会員
				request.getRequestDispatcher("/logout").forward(request, response); // /logoutへフォワード
			}
		}
	}
}
