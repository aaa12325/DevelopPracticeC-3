package servlet;

public class DeleteUserServlet {

}
