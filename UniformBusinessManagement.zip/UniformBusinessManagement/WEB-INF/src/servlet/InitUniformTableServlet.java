package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Uniform;
import dao.UniformDAO;
//作成クラス
import util.FileIn;

public class InitUniformTableServlet extends HttpServlet {

	//get
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException, IOException{

		String error = null; //エラーメッセージ
		String cmd = "menu"; //エラーページ制御

		try {

			//DBの書籍情報を確認
			ArrayList<Uniform> uniformList = new UniformDAO().selectAll();

			//1件以上でもある場合初期ファイルを読み込まない。
			if(uniformList.size() > 0) { //※selectAll()はnullを返さない
				error = "DBにはデータが存在するので、初期データは登録できません。 ";
				return; //finallyに飛ぶ
			}

			//初期ファイルの絶対パスを取得
			String path = getServletContext().getRealPath("file/initial_data.csv");

			//メソッドの呼び出し先でエラーメッセージを更新するためのStringBuilder
			StringBuilder sb = new StringBuilder("");

			//ファイルを読み込み結果をbook_listとして受け取る
			//作成メソッド
			uniformList = insertIniData(path,sb);

			if(!(sb.toString().equals(""))){//insertIniDataでエラーが発生していた場合
				error = sb.toString();
			}

			if(uniformList == null) { //ファイル読み込み中にエラーがあった場合
				return; //finallyに飛ぶ
			}

			//リクエストスコープにbook_listを登録
			request.setAttribute("uniformList",uniformList);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、初期データ登録は行えません。 ";
			cmd = "logout"; //エラーページのリンクをlogoutに変更

		}catch(Exception e) {
			cmd = "logout";
			error = "想定外のエラー";

		}finally{
			if(error == null) { //正常な場合

				request.getRequestDispatcher("/view/insertIniData.jsp").forward(request, response);

			}else { //エラーが起きていた場合

				//エラーページに遷移
				request.setAttribute("cmd", cmd);
				request.setAttribute("error", error);
				request.getRequestDispatcher("/view/error.jsp").forward(request,response);
			}
		}
	}

	//初期ファイルの内容をDBに登録及び、book_listとして返すメソッド
	private ArrayList<Uniform> insertIniData(String path,StringBuilder sb)
	throws IllegalStateException{

		final String iniImage = "no_image.jpg";

		FileIn fileIn = new FileIn(); //ファイル読み込みクラス
		UniformDAO uniformDao = new UniformDAO(); //DAO

		String line = null; //ファイルの一行に相当する
		String[] uniformData = new String[3]; //一行を分割した文字列群を格納

		ArrayList<Uniform> uniformList = new ArrayList<Uniform>(); //戻り値

		//open
		if (!(fileIn.open(path))) { //初期ファイルが無い場合
			sb.delete(0, sb.length()); //StringBuilderの初期化
			sb.append("初期データファイルが無い為、登録は行えません。 ");
			return null;
		}

		//最後まで読んだら終了
		while (true) {

			//一行を読む
			line = fileIn.readLine();
			if (line == null) { //読めなかったら
				break;
			}

			//コンマで分割し格納
			uniformData = line.split(",");

			//情報のうちどれかが欠けていた場合
			if (uniformData.length < 6) {
				sb.delete(0, sb.length());
				sb.append("初期データファイルが不備がある為、登録は行えません。 ");
				return null;
			}

			//価格が数値かどうかを確認するため
			try {
				Uniform uniform = new Uniform();

				//値を格納
				uniform.setProductId(uniformData[0]);
				uniform.setName(uniformData[1]);
				uniform.setPrice(Integer.parseInt(uniformData[2]));
				uniform.setMaterial(uniformData[3]);
				uniform.setDetail(uniformData[4]);
				uniform.setStock(Integer.parseInt(uniformData[5]));
				uniform.setImagePath(iniImage);

				//リストに追加
				uniformList.add(uniform);

				//DBに挿入
				uniformDao.insert(uniform);
			}
			catch (NumberFormatException e) { //価格に文字列
				sb.delete(0, sb.length());
				sb.append("初期データファイルが不備がある為、登録は行えません。 ");
				return null;
			}
		}

		//クローズ
		if (!(fileIn.close())) {
			sb.delete(0, sb.length());
			sb.append("ファイルクローズに失敗しました。");
			return null;
		}

		return uniformList;
	}
}