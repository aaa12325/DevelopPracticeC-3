package bean;

public class Order {

}
