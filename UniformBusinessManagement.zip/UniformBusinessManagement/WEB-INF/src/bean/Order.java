package bean;

import java.util.ArrayList;

public class Order{

	//No
	private int number;
	//合計金額
	private int totalPrice;
	//住所ID
	private int addressId;
	//注文日
	private String orderDate;
	//入金日
	private String dateOfDeposit;
	//発送日
	private String shipDate;
	//入金状況
	private String paymentStatus;
	//発送状況
	private String shippingStatus;
	//詳細
	private String detail;
	//更新日
	private String modifiedDate;
	//メールアドレス(外部キー)
	private String mail;
	//削除フラグ
	private String deleteFlag;

	//注文者
	User user;
	//住所
	Address address;
	//注文内容
	private ArrayList<OrderedUniform> orderedUniformList;

	public Order() {
		this.number = 0;
		this.totalPrice = 0;
		this.addressId =0;
		this.orderDate = null;
		this.dateOfDeposit = null;
		this.shipDate = null;
		this.paymentStatus = null;
		this.shippingStatus = null;
		this.detail = null;
		this.deleteFlag = null;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId= addressId;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getDateOfDeposit() {
		return dateOfDeposit;
	}

	public void setDateOfDeposit(String dateOfDeposit) {
		this.dateOfDeposit = dateOfDeposit;
	}

	public String getShipDate() {
		return shipDate;
	}

	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getShippingStatus() {
		return shippingStatus;
	}

	public void setShippingStatus(String shippingStatus) {
		this.shippingStatus = shippingStatus;
	}

	public String getDetail() {
		return detail;
    }

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getModifiedDate() {
		return modifiedDate;
    }

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
    }

	public ArrayList<OrderedUniform> getOrderedUniformList(){
		return orderedUniformList;
	}

	public void setOrderedUniformList(ArrayList<OrderedUniform> orderedUniformList){
		this.orderedUniformList = orderedUniformList;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
}