package bean;

import java.sql.Timestamp;

public class User{

	// 氏名
	private String name;
	// 氏名（ふりがな）
	private String namePhonetic;
	// メール
	private String mail;
	// パスワード
	private String password;
	// 住所ID
	private int addressId;
	// 電話番号
	private String telephoneNumber;
	// 登録日
	private Timestamp registrationDate;
	// 更新日
	private Timestamp modifiedDate;
	// 削除フラグ
	private String deleteFlag;

	public User() {
		this.name = null;
		this.namePhonetic = null;
		this.mail = null;
		this.password = null;
		this.addressId = 0;
		this.telephoneNumber = null;
		this.deleteFlag = null;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName_phonetic() {
		return namePhonetic;
	}

	public void setName_phonetic(String namePhonetic) {
		this.namePhonetic = namePhonetic;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAddress_id() {
		return addressId;
	}

	public void setAddress_id(int addressId) {
		this.addressId = addressId;
	}

	public String getTelephone_number() {
		return telephoneNumber;
	}

	public void setTelephone_number(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public Timestamp getRegistration_date() {
		return registrationDate;
	}

	public void setRegistration_date(Timestamp registrationDate) {
		this.registrationDate = registrationDate;
	}

	public Timestamp getModified_date() {
		return modifiedDate;
	}

	public void setModified_date(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getDelete_flag() {
		return deleteFlag;
	}

	public void setDelete_flag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
}

