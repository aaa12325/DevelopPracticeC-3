package bean;
/**
 * 購入ユニフォーム情報（購入番号、購入個数、商品ID）を一つのオブジェクトとしてまとめるためのDTOクラス
 */
public class OrderedUniform extends Uniform{

	/**
	 * 購入№
	 */
	private int orderNumber;
	/**
	 * 購入個数
	 */
	private int purchaseNumber;
	/**
	 * 商品ID
	 */
	private String productId;

	/**
	 * コンストラクタ<br>
	 * 購入ユニフォームの初期設定をおこなう
	 */
	public OrderedUniform() {
		this.orderNumber = 0;
		this.purchaseNumber = 0;
		this.productId = null;
	}

	/**
	 * 購入№を取得する
	 *
	 * @return 購入№
	 */
	public int getOrderNumber() {
		return orderNumber;
	}

	/**
	 * 購入№を設定する
	 *
	 * @param orderNumber
	 *            設定する購入№
	 */
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	/**
	 * 購入個数を取得する
	 *
	 * @return 購入個数
	 */
	public int getPurchaseNumber() {
		return purchaseNumber;
	}

	/**
	 * 購入個数を設定する
	 *
	 * @param purchaseNumber
	 *            設定する購入個数
	 */
	public void setPurchaseNumber(int purchaseNumber) {
		this.purchaseNumber = purchaseNumber;
	}

	/**
	 * 商品IDを取得する
	 *
	 * @return 商品ID
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * 商品IDを設定する
	 *
	 * @param productId
	 *            設定する商品ID
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

}

