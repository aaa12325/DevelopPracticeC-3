package bean;

public class Address {

	private int addressId;//住所ID
	private String zipCode;//郵便番号
	private String prefecture;//都道府県
	private String municipalities;//市区町村
	private String houseNumber;//町名・番地
	private String other;//その他建物名

	public Address() {
		this.addressId = 0;
		this.zipCode = null;
		this.prefecture = null;
		this.municipalities = null;
		this.houseNumber = null;
		this.other = null;
	}

	//住所ID
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public int getAddressId() {
		return addressId;
	}

	//郵便番号
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getZipCode() {
		return zipCode;
	}

	//都道府県
	public void setPrefecture(String prefecture) {
		this.prefecture = prefecture;
	}
	public String getPrefecture() {
		return prefecture;
	}

	//市区町村
	public void setMunicipalities(String municipalities) {
		this.municipalities = municipalities;
	}
	public String getMunicipalities() {
		return municipalities;
	}

	//町名・番地
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String getHouseNumber() {
		return houseNumber;
	}

	//その他建物名
	public void setOther(String other) {
		this.other = other;
	}
	public String getOther() {
		return other;
	}
}
