package bean;

public class Address {

	private int addressId;//住所ID
	private String zipCode;//郵便番号
	private String prefecture;//都道府県
	private String municipalities;//市区町村
	private String houseNumber;//町名・番地
	private String other;//その他建物名
	private String telephoneNumber;//電話番号

	public Address() {
		this.addressId = 0;
		this.zipCode = null;
		this.prefecture = null;
		this.municipalities = null;
		this.houseNumber = null;
		this.other = null;
		this.telephoneNumber = null;
	}

	//住所ID
	public void setaddress_id(int addressId) {
		this.addressId = addressId;
	}
	public int getaddress_id() {
		return addressId;
	}

	//郵便番号
	public void setzip_code(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getzip_code() {
		return zipCode;
	}

	//都道府県
	public void setperfecture(String prefecture) {
		this.prefecture = prefecture;
	}
	public String getperfecture() {
		return prefecture;
	}

	//市区町村
	public void setmunicipalities(String municipalities) {
		this.municipalities = municipalities;
	}
	public String getmunicipalities() {
		return municipalities;
	}

	//町名・番地
	public void sethouse_number(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String gethouse_number() {
		return houseNumber;
	}

	//その他建物名
	public void setother(String other) {
		this.other = other;
	}
	public String get() {
		return other;
	}

	//電話番号
	public void settelephone_number(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}
	public String gettelephone_number() {
		return telephoneNumber;
	}
}
