package bean;

import java.sql.Timestamp;

public class Uniform {
	// 商品ID
	private String productId;
	// 名前
	private String name;
	// 価格
	private int price;
	// 素材
	private String material;
	// 詳細（備考）
	private String detail;
	//在庫
	private int stock;
	// 画像パス
	private String imagePath;
	// 登録日
	private Timestamp registrationDate;
	// 更新日
	private Timestamp modifiedDate;
	// 削除フラグ
	private String deleteFlag;

	public Uniform() {
		// 初期化

		this.productId = null;
		this.name = null;
		this.price = 0;
		this.material = null;
		this.detail = null;
		this.imagePath = null;
		this.deleteFlag = null;

	}

	public String getProductId() {
		return this.productId;
	}

	public void setProductId(String ProductId) {
		this.productId = ProductId;
	}

	public String getName() {
		return this.name;

	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return this.price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getMaterial() {
		return this.material;

	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getDetail() {
		return this.detail;

	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public int getStock() {
		return stock;

	}
	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getImagePath() {
		return this.imagePath;

	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public Timestamp getRegistrationDate() {
		return this.registrationDate;

	}

	public void setRegistrationDate(Timestamp registrationDate) {
		this.registrationDate = registrationDate;
	}

	public Timestamp getModifiedDate() {
		return this.modifiedDate;

	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getDeleteFlag() {
		return this.deleteFlag;

	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
}