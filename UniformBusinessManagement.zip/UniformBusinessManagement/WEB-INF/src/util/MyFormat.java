/*
 * プログラム名 : 書籍管理システムDB版Ver2.0
 * プログラムの説明 :ISBN、タイトル、価格の書籍情報をデータベースに登録、削除、変更、一覧表示
 * 					といった操作が行えるプログラムです。
 * ファイルの説明:価格表示を変更します。
 * 作成者 : 小野 凌輔
 * 作成日 : 2022年4月20日
 */

package util;

import java.text.DecimalFormat;

public class MyFormat {

	//価格表記変換メソッド
	public String moneyFormat(int price) {

		//フォーマットは3桁区切りのコンマ、先頭に\マーク、小数点2桁表示
		DecimalFormat dec = new DecimalFormat("###,###円");

		//変換後の文字列を返す
		return dec.format(price);
	}

}