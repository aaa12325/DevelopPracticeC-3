package util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

/**
 * 日時のフォーマットに関するクラス
 *
 */
public class DateFormat {

	public  String dateFormat(Timestamp date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd");
		String str =sdf.format(date);
		return str;
	}

	public String timeFormat(Timestamp time) {
		SimpleDateFormat sdf = new SimpleDateFormat("HH時mm分");
		String str =sdf.format(time);
		return str;
	}

}
