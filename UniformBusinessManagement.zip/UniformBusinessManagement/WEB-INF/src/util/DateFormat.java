package util;

import java.text.SimpleDateFormat;
import com.sun.jmx.snmp.Timestamp;

/**
 * 日時のフォーマットに関するクラス
 *
 */
public class DateFormat {

	public  String dateFormat(Timestamp date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd");
		String str =sdf.format(date);
		return str;
	}

	public String timeFormat(Timestamp time) {
		SimpleDateFormat sdf = new SimpleDateFormat("HH時mm分");
		String str =sdf.format(time);
		return str;
	}

}
