package util;

import java.util.Properties;
import java.util.ArrayList;
import java.util.Date;

import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;

import javax.mail.internet.InternetAddress;


//作成クラス
import bean.Order;
import bean.OrderedUniform;
import bean.User;

public class SendMail {

	//第一引数の購入内容を第二引数のユーザーにメールで通知するメソッド
	public void sendOrderMail(Order order) {

		try {

			User user = order.getUser();

			//メール本文、冒頭テンプレート
			String mailBody = user.getName() + "様。\n\nいつもお世話になっております。\n株式会社神田ユニフォームでございます。\n\n"
					+ "この度はユニフォームのご購入ありがとうございます。\n"
					+ "以下の注文内容でお間違いなければ、ご入金手続きの程よろしくお願い致します。\n\n"
					+ "------------------------------------------------------------------------------\n\n";

			//メールアドレス
			String email = user.getMail();

			//メール送信用
			MimeMessage mimeMessage = sendReady();

			//注文内容取得
			ArrayList<OrderedUniform> list = order.getOrderedUniformList();

			//購入内容をメール本文に追加。
			for(int i = 0; i < list.size(); i++) {
				OrderedUniform uniform = list.get(i);
				mailBody += "種類：" + uniform.getName() + " "
						 +  "価格；" + uniform.getPrice() + "\n"
				total += book.getPrice() * book.getQuantity(); //小計を合計値に加算
			}
			//合計金額、挨拶を追加
			mailBody += "合計 " + String.valueOf(total) +"円\n\n"
					 + "またのご利用よろしくお願いします。";

			// 送信元メールアドレスと送信者名を指定
			mimeMessage.setFrom(new InternetAddress("system.project.team31@kanda-it-school-system.com", "株式会社神田ユニフォーム", "iso-2022-jp"));

			// 送信先メールアドレスを指定
			mimeMessage.setRecipients(Message.RecipientType.TO, email);

			// メールのタイトルを指定
			mimeMessage.setSubject("ご購入ありがとうございました。", "iso-2022-jp");

			// メールの内容を指定
			mimeMessage.setText(mailBody, "iso-2022-jp");

			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("送信に失敗しました。\n" + e);
		}
	}

	//第一引数の購入内容を第二引数のユーザーにメールで通知するメソッド
	public void sendInquiredMail(Inquiry inquiry) {

		try {

			//問い合わせ者名
			String userName = inquiry.getName();

			//メールアドレス
			String email = inquiry.getEmail();

			//メール送信用
			MimeMessage mimeMessage = sendReady();

			//メール本文、冒頭テンプレート
			String mailBody = userName + "様\n\nこの度はお問い合わせいただき、ありがとうございます。\n"
							+ "以下内容で問い合わせを受け付けましたので、ご連絡いたします。\n\n";

			//メール本文に追加。
			mailBody += "問い合わせ件名:" + inquiry.getCotitle() + "\n" +
						"問い合わせ内容:" + inquiry.getComment() + "\n\n";

			//挨拶を追加
			mailBody += "本メールからの返信によるお問い合わせは受け付けておりません。\n" +
						"回答の際にはご記入いただいた電話番号及びメールアドレスから再度ご連絡致します。\n" +
						"今しばらくお待ちください。";

			// 送信元メールアドレスと送信者名を指定
			mimeMessage.setFrom(new InternetAddress("system.project.team31@kanda-it-school-system.com", "株式会社神田ユニフォーム", "iso-2022-jp"));

			// 送信先メールアドレスを指定
			mimeMessage.setRecipients(Message.RecipientType.TO, email);

			// メールのタイトルを指定
			mimeMessage.setSubject("【神田IT school】お問い合わせありがとうございます。", "iso-2022-jp");

			// メールの内容を指定
			mimeMessage.setText(mailBody, "iso-2022-jp");

			// メールの形式を指定
			mimeMessage.setHeader("Content-Type", "text/plain; charset=iso-2022-jp");

			// 送信日付を指定
			mimeMessage.setSentDate(new Date());

			// 送信します
			Transport.send(mimeMessage);

			// 送信成功
			System.out.println("送信に成功しました。");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("送信に失敗しました。\n" + e);
		}
	}

	//Gmail送信準備を行うメソッド
	private MimeMessage sendReady() {

		Properties props = System.getProperties();

		// SMTPサーバのアドレスを指定（今回はxserverのSMTPサーバを利用）
		props.put("mail.smtp.host", "sv5215.xserver.jp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.debug", "true");
		//props.put("mail.smtp.ssl.trust", "smtp.gmail.com"); //Could not convert socket to TLSが出た場合に追加

		Session session = Session.getInstance(
			props,
			new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("system.project.team31@kanda-it-school-system.com", "XXu9C6EyyT");
				}
			}
		);

		return new MimeMessage(session);
	}
}
